﻿using System;

public class Vehicle
{

    public int Id { get; set; }
    public string Brand { get; set; } = string.Empty;

    public string Vin { get; set; } = string.Empty;
    public string Color { get; set; } = string.Empty;
    public int Year { get; set; }
    public int OwnerId { get; set; }
    public Owner owner { get; set; }
    public List<Claims> Claims { get; set; }



}
