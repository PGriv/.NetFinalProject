﻿using System;


    public class Claims
{
    public int Id { get; set; }
    public string Description { get; set; } = string.Empty;
    public bool Status { get; set; } = true;
    public int VehicleId { get; set; }
    public Vehicle? vehicle { get; set; }
}
