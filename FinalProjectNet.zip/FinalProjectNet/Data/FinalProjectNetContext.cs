﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FinalProjectNet.Data
{
    public class FinalProjectNetContext : DbContext
    {
        public FinalProjectNetContext (DbContextOptions<FinalProjectNetContext> options)
            : base(options)
        {
        }

        public DbSet<Claims> Claims { get; set; } = default!;

        public DbSet<Owner> Owner { get; set; }

        public DbSet<Vehicle> Vehicle { get; set; }
    }
}
